
class TweetItemModel {

  String tweet;
  String username;
  String time;
  String twitterHandle;

  TweetItemModel(this.tweet, this.username, this.time, this.twitterHandle);

}
